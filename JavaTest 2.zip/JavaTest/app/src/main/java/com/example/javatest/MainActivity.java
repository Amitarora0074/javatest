package com.example.javatest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText Name;
    private  EditText Password;
    private Button Login;
    private TextView Msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Name = (EditText)findViewById(R.id.txtName);
        Password=(EditText)findViewById(R.id.txtPassword);
        Login=(Button)findViewById(R.id.btLogin);
        Msg=(TextView)findViewById(R.id.txtMsg);
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(Name.getText().toString(),Password.getText().toString());
            }
        });
    }

    private void validate(String userName, String password){
        if ((userName.equals("student1")) && (password.equals("123456"))){
            Intent intent=new Intent(this, MainActivity2.class);
            startActivity(intent);
        }
        else {
            Msg.setText("Invalid Username or Password");
        }

    }
}