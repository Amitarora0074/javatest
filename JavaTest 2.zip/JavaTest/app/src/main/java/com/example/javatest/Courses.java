package com.example.javatest;

public class Courses {
    private String courseName;
    private int courseFees;
    private int courseHours;

    public Courses(String courseName, int courseFees, int courseHours) {
        this.courseName = courseName;
        this.courseFees = courseFees;
        this.courseHours = courseHours;
    }

    public String getCourseName() {
        return courseName;
    }

    public int getCourseFees() {
        return courseFees;
    }

    public int getCourseHours() {
        return courseHours;
    }
}
