package com.example.javatest;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity implements AdapterView.OnItemClickListener {
    String courses[]={"Java","Swift","iOS","Android","Database"};
    ArrayList<Courses> courseList = new ArrayList<>();
    ArrayList<Courses> temp = new ArrayList<>();
    private TextView Hello;
    Spinner sp;
    RadioButton grad,ungrad;
    TextView fees,hours,amt;
    Button add;
    CheckBox accomo,medIns;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Filldata();

        Hello=(TextView)findViewById(R.id.txtHello);
        sp=findViewById(R.id.spinner);
        grad=findViewById(R.id.rbGrad);
        ungrad=findViewById(R.id.rbUngrad);
        fees=findViewById(R.id.txtFees);
        hours=findViewById(R.id.txtHours);
        amt=findViewById(R.id.txtAmt);
        add=findViewById(R.id.btAdd);
        accomo=findViewById(R.id.cbAccomo);
        medIns=findViewById(R.id.cbMI);

        ArrayAdapter aa=new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,courses);
        sp.setAdapter(aa);
        fees.setText(String.valueOf(courseList.get(0).getCourseFees()));
        hours.setText(String.valueOf(courseList.get(0).getCourseHours()));

        sp.setOnItemClickListener(this);



        Hello.setText("hello student");
    }
    public void Filldata(){
        courseList.add(new Courses("Java",1300,6));
        courseList.add(new Courses("Swift",1500,5));
        courseList.add(new Courses("iOS",1350,5));
        courseList.add(new Courses("Android",1400,7));
        courseList.add(new Courses("Database",1000,4));
    }
    public Courses getCourseObj(String courseNam){
        for (int i=0;i<courseList.size();i++){
            if(courseNam.equals(courseList.get(i).getCourseName())){
                return courseList.get(i);
            }
        }
        return null;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
        Courses obj=getCourseObj(courses[i]);
        fees.setText(String.valueOf(obj));
        hours.setText(String.valueOf(obj.getCourseHours()));
    }
}